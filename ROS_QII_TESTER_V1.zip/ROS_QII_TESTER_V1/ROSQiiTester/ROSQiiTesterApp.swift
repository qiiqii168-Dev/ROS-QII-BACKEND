import SwiftUI

@main
struct ROSQiiTesterApp: App {
    var body: some Scene { WindowGroup { ContentView() } }
}

struct CheckResult: Identifiable {
    let id = UUID()
    let name: String
    let detail: String
    let passed: Bool
}

@MainActor
final class TesterModel: ObservableObject {
    @Published var baseURL = "https://ros-qii-backend.onrender.com"
    @Published var isRunning = false
    @Published var results: [CheckResult] = []
    @Published var lastRun = "Not tested yet"

    func runChecks() async {
        guard let base = URL(string: baseURL.trimmingCharacters(in: .whitespacesAndNewlines).trimmingCharacters(in: CharacterSet(charactersIn: "/"))) else {
            results = [CheckResult(name: "Server URL", detail: "Invalid URL", passed: false)]
            return
        }
        isRunning = true
        results = []
        defer { isRunning = false; lastRun = Date.now.formatted(date: .abbreviated, time: .shortened) }

        await check(path: "/health", label: "Backend Health", base: base) { data, response in
            let body = String(data: data, encoding: .utf8) ?? "(no response body)"
            let ok = (200..<300).contains(response.statusCode) && body.localizedCaseInsensitiveContains("ok")
            return (ok, "HTTP \(response.statusCode) · \(body.prefix(220))")
        }
        await check(path: "/v2/ros/online-count", label: "Online Count API", base: base) { data, response in
            let body = String(data: data, encoding: .utf8) ?? "(no response body)"
            let ok = (200..<300).contains(response.statusCode)
            return (ok, "HTTP \(response.statusCode) · \(body.prefix(220))")
        }
    }

    private func check(path: String, label: String, base: URL,
                       evaluate: (Data, HTTPURLResponse) -> (Bool, String)) async {
        guard let url = URL(string: path, relativeTo: base)?.absoluteURL else {
            results.append(CheckResult(name: label, detail: "Could not build URL", passed: false)); return
        }
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.timeoutInterval = 25
        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse else {
                results.append(CheckResult(name: label, detail: "Not an HTTP response", passed: false)); return
            }
            let (passed, detail) = evaluate(data, http)
            results.append(CheckResult(name: label, detail: detail, passed: passed))
        } catch {
            results.append(CheckResult(name: label, detail: error.localizedDescription, passed: false))
        }
    }
}

struct ContentView: View {
    @StateObject private var model = TesterModel()
    var body: some View {
        NavigationStack {
            Form {
                Section("ROS QII TESTER · v1") {
                    Text("Backend diagnostics")
                        .font(.headline)
                    Text("This is a separate test utility. It does not modify or launch the original ROS game.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                Section("Backend") {
                    TextField("https://server.example.com", text: $model.baseURL)
                        .textInputAutocapitalization(.never)
                        .keyboardType(.URL)
                        .autocorrectionDisabled()
                    Button {
                        Task { await model.runChecks() }
                    } label: {
                        HStack {
                            if model.isRunning { ProgressView() }
                            Text(model.isRunning ? "Testing…" : "Run Server Tests")
                        }.frame(maxWidth: .infinity)
                    }.disabled(model.isRunning)
                }
                Section("Results · \(model.lastRun)") {
                    if model.results.isEmpty {
                        Text("Press Run Server Tests to begin.").foregroundStyle(.secondary)
                    } else {
                        ForEach(model.results) { result in
                            HStack(alignment: .top, spacing: 10) {
                                Image(systemName: result.passed ? "checkmark.circle.fill" : "xmark.circle.fill")
                                    .foregroundStyle(result.passed ? .green : .red)
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(result.name).font(.headline)
                                    Text(result.detail).font(.caption).textSelection(.enabled)
                                }
                            }
                        }
                        let passed = model.results.filter(\.passed).count
                        Text("\(passed)/\(model.results.count) checks passed")
                            .font(.subheadline.bold())
                    }
                }
                Section("Original ROS reference") {
                    LabeledContent("Bundle ID", value: "net.roslegacy.ios")
                    LabeledContent("Version", value: "1.610637.617289")
                    Text("Reference information read from the uploaded Info.plist. The tester does not inspect another app's private files.")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
            .navigationTitle("ROS QII Tester")
        }
    }
}

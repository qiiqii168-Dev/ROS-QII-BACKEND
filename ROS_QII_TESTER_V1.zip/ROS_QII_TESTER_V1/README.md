# ROS QII TESTER v1

A standalone iOS diagnostics utility for the already-deployed ROS QII backend.

## What it tests
- `GET /health`: expects HTTP 2xx and a response containing `ok`.
- `GET /v2/ros/online-count`: reports whether this endpoint responds with HTTP 2xx.

The second endpoint is checked as observed in the uploaded `rosauthhook.dylib` strings. A failed check may mean the backend does not implement that route or requires a different HTTP method/authentication.

## Build IPA with GitHub Actions
1. Upload the contents of this folder to the root of a GitHub repository (keep `.github/workflows/build.yml`).
2. Open **Actions** → **Build ROS QII Tester IPA** → **Run workflow**.
3. When complete, open the run and download artifact **ROS-QII-TESTER-unsigned-IPA**.
4. The IPA is unsigned. Sign it with a signing method you are authorized to use before installing on iPhone.

## Important limits
- This app is a separate tester; it does not patch, embed, or launch the original ROS client.
- It does not claim that the backend supports the original game's BigWorld game-server protocol.
- It does not create accounts or send passwords. Login/Ticket testing requires inspecting the exact backend request models first.
- Original ROS reference metadata comes from the supplied `Info.plist`: bundle ID `net.roslegacy.ios`, version `1.610637.617289`.
